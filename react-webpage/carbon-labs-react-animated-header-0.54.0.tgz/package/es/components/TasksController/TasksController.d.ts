/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { ButtonBaseProps, DropdownProps } from '@carbon/react';
import { TileGroup } from '../AnimatedHeader/types';
export interface TasksControllerConfig {
    type: 'button' | 'dropdown' | null;
    isLoading?: boolean;
    button?: {
        text: string;
        propsOverrides?: Partial<ButtonBaseProps>;
    };
    dropdown?: {
        propsOverrides?: Partial<Omit<DropdownProps<TileGroup>, 'id' | 'items' | 'selectedItem'>>;
        label?: string;
        ariaLabel?: string;
    };
}
export type TasksControllerProps = {
    tasksControllerConfig?: TasksControllerConfig | null;
    isLoading?: boolean;
    allTileGroups?: TileGroup[];
    selectedTileGroup?: TileGroup;
    setSelectedTileGroup?: (e: any) => void;
};
declare const TasksController: ({ tasksControllerConfig, isLoading, allTileGroups, selectedTileGroup, setSelectedTileGroup, }: TasksControllerProps) => React.JSX.Element | null;
export default TasksController;
