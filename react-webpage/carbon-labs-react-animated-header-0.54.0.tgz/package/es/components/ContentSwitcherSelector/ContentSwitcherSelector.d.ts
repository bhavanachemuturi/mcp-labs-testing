/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { type ContentSwitcherProps } from '@carbon/react';
export type ContentSwitcherItem = {
    id?: string;
    text: string;
    onSelect?: () => void;
};
export type ContentSwitcherConfig = Omit<ContentSwitcherProps, 'children' | 'onChange' | 'size' | 'lowContrast'> & {
    items: ContentSwitcherItem[];
    ariaLabel?: string;
    isLoading?: boolean;
    lowContrast?: boolean;
    visibleCount?: 2 | 3;
    onChange?: ContentSwitcherProps['onChange'];
};
export type ContentSwitcherSelectorProps = {
    contentSwitcherConfig?: ContentSwitcherConfig | null;
    isLoading?: boolean;
    headerExpanded?: boolean;
};
declare const ContentSwitcherSelector: React.FC<ContentSwitcherSelectorProps>;
export default ContentSwitcherSelector;
