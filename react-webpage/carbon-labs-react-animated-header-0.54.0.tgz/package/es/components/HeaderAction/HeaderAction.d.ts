/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import type { HeaderActionConfig } from './header-action.types';
declare const HeaderAction: React.FC<{
    config: HeaderActionConfig;
    headerExpanded: boolean;
}>;
export default HeaderAction;
