/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { DropdownProps } from '@carbon/react';
import React from 'react';
export interface Workspace {
    id: string;
    label: string;
}
export type WorkspaceSelectorConfig = {
    propsOverrides: Partial<Omit<DropdownProps<Workspace>, 'id' | 'items' | 'selectedItem' | 'setSelectedWorkspace'>>;
    ariaLabel?: string;
    allWorkspaces: Workspace[];
    selectedWorkspace?: Workspace | null;
    setSelectedWorkspace: (e: any) => void;
    isLoading?: boolean;
};
export type WorkspaceSelectorProps = {
    workspaceSelectorConfig?: WorkspaceSelectorConfig | null;
    userName?: string;
    isLoading?: boolean;
};
declare const WorkspaceSelector: ({ workspaceSelectorConfig, userName, isLoading, }: WorkspaceSelectorProps) => React.JSX.Element | null;
export default WorkspaceSelector;
