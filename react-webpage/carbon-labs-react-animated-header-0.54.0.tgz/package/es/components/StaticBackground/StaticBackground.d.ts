import React from 'react';
export interface StaticBackgroundProps {
    headerStatic?: React.JSX.Element | string;
}
declare const StaticBackground: React.FC<StaticBackgroundProps>;
export default StaticBackground;
