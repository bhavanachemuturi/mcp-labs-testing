/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { ElementType, ReactNode } from 'react';
import { type TagProps } from '@carbon/react';
type TagTypeName = TagProps<'div'>['type'];
export type GlassTileBodyProps = {
    open?: boolean;
    title?: string | null;
    subtitle?: string | null;
    customContent?: ReactNode;
    primaryIcon?: ElementType | null;
    secondaryIcon?: ElementType | null;
    tagLabel?: string | null;
    tagType?: TagTypeName;
    isLoading?: boolean;
};
export declare const GlassTileBody: ({ open, title, subtitle, customContent, primaryIcon: PrimaryIcon, secondaryIcon: SecondaryIcon, tagLabel, tagType, isLoading, }: GlassTileBodyProps) => React.JSX.Element;
export {};
