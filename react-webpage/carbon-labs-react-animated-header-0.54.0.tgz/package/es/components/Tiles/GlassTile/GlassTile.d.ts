/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { ElementType } from 'react';
import { GlassTileBodyProps } from './GlassTileBody';
import { AutotrackDataAttributes } from '../../types';
export type GlassTileProps = {
    variant?: 'glass';
    tileId: string;
    href?: string | null;
    title?: string | null;
    subtitle?: string | null;
    disabledTaskLabel?: string | null;
    customContent?: React.ReactNode | null;
    primaryIcon?: ElementType | null;
    secondaryIcon?: ElementType | null;
    tagLabel?: string | null;
    tagType?: GlassTileBodyProps['tagType'];
    onClick?: ((event: React.MouseEvent<HTMLElement>) => void) | null;
    ariaLabel?: string;
    open?: boolean;
    isLoading?: boolean;
    isDisabled?: boolean;
} & AutotrackDataAttributes;
export declare const GlassTile: React.FC<GlassTileProps>;
