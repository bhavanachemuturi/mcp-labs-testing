/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { ElementType } from 'react';
import { AITileBodyProps, AITileLabelVariant } from '../AITile/AITileBody';
import { AutotrackDataAttributes } from '../../types';
export type AITileProps = {
    variant: 'ai';
    tileId: string;
    href?: string | null;
    title?: string | null;
    subtitle?: string | null;
    disabledTaskLabel?: string | null;
    customContent?: React.ReactNode | null;
    primaryIcon?: ElementType | null;
    secondaryIcon?: ElementType | null;
    aiLabelVariant?: AITileLabelVariant;
    aiLabelText?: string;
    aiLabelTagType?: AITileBodyProps['aiLabelTagType'];
    onClick?: ((event: React.MouseEvent<HTMLElement>) => void) | null;
    ariaLabel?: string;
    open?: boolean;
    isLoading?: boolean;
    isDisabled?: boolean;
} & AutotrackDataAttributes;
export declare const AITile: React.FC<AITileProps>;
export default AITile;
