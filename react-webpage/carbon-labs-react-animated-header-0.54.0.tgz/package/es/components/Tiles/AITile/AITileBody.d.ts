/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { ElementType, ReactNode } from 'react';
import { type TagProps } from '@carbon/react';
type TagTypeName = TagProps<'div'>['type'];
export type AITileLabelVariant = 'aiLabel' | 'tag';
export type AITileBodyProps = {
    open?: boolean;
    title?: string | null;
    subtitle?: string | null;
    customContent?: ReactNode;
    primaryIcon?: ElementType | null;
    secondaryIcon?: ElementType | null;
    aiLabelVariant?: AITileLabelVariant;
    aiLabelText?: string;
    aiLabelTagType?: TagTypeName;
    isLoading?: boolean;
};
export declare const AITileBody: ({ open, title, subtitle, customContent, primaryIcon: PrimaryIcon, secondaryIcon: SecondaryIcon, aiLabelVariant, aiLabelText, aiLabelTagType, isLoading, }: AITileBodyProps) => React.JSX.Element;
export {};
