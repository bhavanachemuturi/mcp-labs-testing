/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { ElementType } from 'react';
import { type AITileBodyProps, type AITileLabelVariant } from '../AITile/AITileBody';
import { AutotrackDataAttributes } from '../../types';
export type AIPromptTileProps = {
    variant: 'aiPrompt';
    tileId: string;
    href?: string | null;
    title?: string | null;
    disabledTaskLabel?: string | null;
    productName?: string;
    promptPlaceholder?: string;
    primaryIcon?: ElementType | null;
    aiLabelVariant?: AITileLabelVariant;
    aiLabelText?: string;
    aiLabelTagType?: AITileBodyProps['aiLabelTagType'];
    onClick?: ((event: React.MouseEvent<HTMLElement>) => void) | null;
    ariaLabel?: string;
    open?: boolean;
    isLoading?: boolean;
    isDisabled?: boolean;
} & AutotrackDataAttributes;
export declare const AIPromptTile: React.FC<AIPromptTileProps>;
