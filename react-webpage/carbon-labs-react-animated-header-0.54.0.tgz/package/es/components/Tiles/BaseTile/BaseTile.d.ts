/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { type AITileProps } from '../AITile/AITile';
import { type AIPromptTileProps } from '../AIPromptTile/AIPromptTile';
import { type GlassTileProps } from '../GlassTile/GlassTile';
/** Base Tile router */
export type TileVariant = 'glass' | 'aiPrompt' | 'ai';
export type BaseTileProps = GlassTileProps | AIPromptTileProps | AITileProps;
export declare const BaseTile: React.FC<BaseTileProps>;
