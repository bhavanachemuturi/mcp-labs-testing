/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { TasksControllerProps } from '../TasksController/TasksController';
import { WorkspaceSelectorProps } from '../WorkspaceSelector/WorkspaceSelector';
import { Tile, TileGroup, AriaLabels } from './types';
import { type ContentSwitcherConfig } from '../ContentSwitcherSelector/ContentSwitcherSelector';
import type { HeaderActionProps } from '../HeaderAction/header-action.types';
/** Animated Header */
export type AnimatedHeaderProps = {
    allTileGroups?: TileGroup[];
    ariaLabels?: AriaLabels;
    selectedTileGroup?: TileGroup;
    setSelectedTileGroup?: (e: any) => void;
    contentSwitcherConfig?: ContentSwitcherConfig;
    description?: string;
    headerAnimation?: object;
    headerStatic?: React.JSX.Element | string;
    productName?: string;
    userName?: string;
    welcomeText?: string;
    isLoading?: boolean;
    disabledTaskLabel?: string;
    expandButtonLabel?: string;
    collapseButtonLabel?: string;
    tileClickHandler?: (tile: Tile) => void;
} & TasksControllerProps & WorkspaceSelectorProps & HeaderActionProps;
declare const AnimatedHeader: React.FC<AnimatedHeaderProps>;
export default AnimatedHeader;
