/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { AriaLabels } from '../AnimatedHeader/types';
export type HeaderTitleProps = {
    userName?: string;
    welcomeText?: string;
    headerExpanded?: boolean;
    ariaLabels?: AriaLabels;
};
declare const HeaderTitle: React.FC<HeaderTitleProps>;
export default HeaderTitle;
