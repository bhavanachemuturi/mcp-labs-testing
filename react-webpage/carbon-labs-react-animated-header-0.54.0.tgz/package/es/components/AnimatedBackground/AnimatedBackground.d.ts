/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
export interface AnimatedBackgroundProps {
    headerAnimation?: object;
    isOpen: boolean;
}
declare const AnimatedBackground: React.FC<AnimatedBackgroundProps>;
export default AnimatedBackground;
