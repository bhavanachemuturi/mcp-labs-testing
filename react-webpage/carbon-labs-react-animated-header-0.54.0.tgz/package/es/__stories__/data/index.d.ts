/**
 * @license
 *
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { TileGroup } from '../../components/AnimatedHeader/types';
import type { HeaderActionConfig } from '../../components/HeaderAction/header-action.types';
import type { ContentSwitcherConfig } from '../../components/ContentSwitcherSelector/ContentSwitcherSelector';
export declare const workspaceData: {
    id: string;
    label: string;
}[];
export declare const headerTiles: TileGroup[];
export declare const tasksControllerConfigButton: {
    type: string;
    button: {
        href: string;
        icon: import("@carbon/icons-react").CarbonIconType;
        text: string;
        type: "tertiary";
    };
};
export declare const tasksControllerConfigDropdown: {
    type: string;
    dropdown: {
        label: string;
        allTileGroups: TileGroup[];
        selectedTileGroup: TileGroup;
        setSelectedTileGroup: () => void;
        ariaLabel: string;
    };
};
export declare const tasksControllerConfigLoading: {
    type: string;
    isLoading: boolean;
};
export declare const contentSwitcherConfigTwo: ContentSwitcherConfig;
export declare const contentSwitcherConfigThree: ContentSwitcherConfig;
export declare const contentSwitcherConfigLoading: ContentSwitcherConfig;
export declare const workspaceSelectorConfig: {
    allWorkspaces: {
        id: string;
        label: string;
    }[];
    setSelectedWorkspace: () => void;
    propsOverrides: {
        label: string;
        renderSelectedItem: (item: any) => string;
    };
    ariaLabel: string;
};
export declare const workspaceSelectorConfigLoading: {
    allWorkspaces: {
        id: string;
        label: string;
    }[];
    setSelectedWorkspace: () => void;
    isLoading: boolean;
};
export declare const headerActionIcon: HeaderActionConfig;
export declare const headerActionGhost: HeaderActionConfig;
