export var assets: any[];
export var ddd: number;
declare namespace header_animated_db2_dark_03 {
    export { v };
    export { fr };
    export { ip };
    export { op };
    export { w };
    export { h };
    export { nm };
    export { ddd };
    export { assets };
    export { layers };
    export { markers };
    export { props };
}
export var fr: number;
export var h: number;
export var ip: number;
export var layers: ({
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
    parent?: undefined;
    shapes?: undefined;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: ({
                i: {
                    x: number;
                    y: number;
                };
                o: {
                    x: number;
                    y: number;
                };
                t: number;
                s: number[];
                to: number[];
                ti: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
                to?: undefined;
                ti?: undefined;
            })[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            d: number;
            ty: string;
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            c?: undefined;
            o?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            r?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            d?: undefined;
            s?: undefined;
            p?: undefined;
            r?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            d?: undefined;
            s?: undefined;
            p?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            d?: undefined;
            mn?: undefined;
            hd?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: ({
                i: {
                    x: number[];
                    y: number[];
                };
                o: {
                    x: number[];
                    y: number[];
                };
                t: number;
                s: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
            })[];
            ix: number;
        };
        p: {
            a: number;
            k: ({
                i: {
                    x: number;
                    y: number;
                };
                o: {
                    x: number;
                    y: number;
                };
                t: number;
                s: number[];
                to: number[];
                ti: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
                to?: undefined;
                ti?: undefined;
            })[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ty: string;
            d: number;
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            ix?: undefined;
            c?: undefined;
            o?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            nm: string;
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            ix: number;
            mn: string;
            hd: boolean;
            d?: undefined;
            s?: undefined;
            p?: undefined;
            c?: undefined;
            o?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            d?: undefined;
            s?: undefined;
            p?: undefined;
            r?: undefined;
            ix?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            d?: undefined;
            s?: undefined;
            p?: undefined;
            ix?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            d?: undefined;
            mn?: undefined;
            hd?: undefined;
            ix?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            r?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            mn?: undefined;
            hd?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: ({
                i: {
                    x: number[];
                    y: number[];
                };
                o: {
                    x: number[];
                    y: number[];
                };
                t: number;
                s: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
            })[];
            ix: number;
        };
        p: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ind: number;
            ty: string;
            ix: number;
            ks: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    }[];
                } | {
                    t: number;
                    s: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    }[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            c?: undefined;
            o?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            r?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            r?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            mn?: undefined;
            hd?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: ({
                i: {
                    x: number[];
                    y: number[];
                };
                o: {
                    x: number[];
                    y: number[];
                };
                t: number;
                s: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
            })[];
            ix: number;
        };
        p: {
            a: number;
            k: ({
                i: {
                    x: number;
                    y: number;
                };
                o: {
                    x: number;
                    y: number;
                };
                t: number;
                s: number[];
                to: number[];
                ti: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
                to?: undefined;
                ti?: undefined;
            })[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ind: number;
            ty: string;
            ix: number;
            ks: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    }[];
                } | {
                    t: number;
                    s: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    }[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            c?: undefined;
            o?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            r?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            r?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            mn?: undefined;
            hd?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: ({
                i: {
                    x: number;
                    y: number;
                };
                o: {
                    x: number;
                    y: number;
                };
                t: number;
                s: number[];
                to: number[];
                ti: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
                to?: undefined;
                ti?: undefined;
            })[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            d: number;
            ty: string;
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            c?: undefined;
            o?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            r?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            d?: undefined;
            s?: undefined;
            p?: undefined;
            r?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            d?: undefined;
            s?: undefined;
            p?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            d?: undefined;
            mn?: undefined;
            hd?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
    parent?: undefined;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: ({
                i: {
                    x: number;
                    y: number;
                };
                o: {
                    x: number;
                    y: number;
                };
                t: number;
                s: number[];
                to: number[];
                ti: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
                to?: undefined;
                ti?: undefined;
            })[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ind: number;
            ty: string;
            ix: number;
            ks: {
                a: number;
                k: {
                    i: number[][];
                    o: number[][];
                    v: number[][];
                    c: boolean;
                };
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            r?: undefined;
            s?: undefined;
            e?: undefined;
            o?: undefined;
            m?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            nm: string;
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            ix: number;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ks?: undefined;
            s?: undefined;
            e?: undefined;
            o?: undefined;
            m?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            e: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            m: number;
            ix: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ks?: undefined;
            r?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            r?: undefined;
            s?: undefined;
            e?: undefined;
            m?: undefined;
            p?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            mn?: undefined;
            hd?: undefined;
            e?: undefined;
            m?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
    parent?: undefined;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: ({
                i: {
                    x: number;
                    y: number;
                };
                o: {
                    x: number;
                    y: number;
                };
                t: number;
                s: number[];
                to: number[];
                ti: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
                to?: undefined;
                ti?: undefined;
            })[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ind: number;
            ty: string;
            ix: number;
            ks: {
                a: number;
                k: {
                    i: number[][];
                    o: number[][];
                    v: number[][];
                    c: boolean;
                };
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            r?: undefined;
            s?: undefined;
            e?: undefined;
            o?: undefined;
            m?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            nm: string;
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            ix: number;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ks?: undefined;
            s?: undefined;
            e?: undefined;
            o?: undefined;
            m?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            s: {
                a: number;
                k: number;
                ix: number;
            };
            e: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            m: number;
            ix: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ks?: undefined;
            r?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            r?: undefined;
            s?: undefined;
            e?: undefined;
            m?: undefined;
            p?: undefined;
            a?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            mn?: undefined;
            hd?: undefined;
            e?: undefined;
            m?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: ({
                i: {
                    x: number;
                    y: number;
                };
                o: {
                    x: number;
                    y: number;
                };
                t: number;
                s: number[];
                to: number[];
                ti: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
                to?: undefined;
                ti?: undefined;
            })[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ind: number;
            ty: string;
            ix: number;
            ks: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    }[];
                } | {
                    t: number;
                    s: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    }[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            c?: undefined;
            o?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            r?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            r?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            mn?: undefined;
            hd?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ind: number;
            ty: string;
            ix: number;
            ks: {
                a: number;
                k: {
                    i: number[][];
                    o: number[][];
                    v: number[][];
                    c: boolean;
                };
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            c?: undefined;
            o?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            r?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            p?: undefined;
            a?: undefined;
            s?: undefined;
            r?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            mn?: undefined;
            hd?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
} | {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    parent: number;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: ({
                i: {
                    x: number;
                    y: number;
                };
                o: {
                    x: number;
                    y: number;
                };
                t: number;
                s: number[];
                to: number[];
                ti: number[];
            } | {
                t: number;
                s: number[];
                i?: undefined;
                o?: undefined;
                to?: undefined;
                ti?: undefined;
            })[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    shapes: {
        ty: string;
        it: ({
            ind: number;
            ty: string;
            ix: number;
            ks: {
                a: number;
                k: {
                    i: number[][];
                    o: number[][];
                    v: number[][];
                    c: boolean;
                };
                ix: number;
            };
            nm: string;
            mn: string;
            hd: boolean;
            s?: undefined;
            e?: undefined;
            o?: undefined;
            m?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            r?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            e: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            m: number;
            ix: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ks?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
            p?: undefined;
            a?: undefined;
            r?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            c: {
                a: number;
                k: number[];
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            w: {
                a: number;
                k: number;
                ix: number;
            };
            lc: number;
            lj: number;
            ml: number;
            bm: number;
            nm: string;
            mn: string;
            hd: boolean;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            s?: undefined;
            e?: undefined;
            m?: undefined;
            p?: undefined;
            a?: undefined;
            r?: undefined;
            sk?: undefined;
            sa?: undefined;
        } | {
            ty: string;
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            o: {
                a: number;
                k: number;
                ix: number;
            };
            sk: {
                a: number;
                k: number;
                ix: number;
            };
            sa: {
                a: number;
                k: number;
                ix: number;
            };
            nm: string;
            ind?: undefined;
            ix?: undefined;
            ks?: undefined;
            mn?: undefined;
            hd?: undefined;
            e?: undefined;
            m?: undefined;
            c?: undefined;
            w?: undefined;
            lc?: undefined;
            lj?: undefined;
            ml?: undefined;
            bm?: undefined;
        })[];
        nm: string;
        np: number;
        cix: number;
        bm: number;
        ix: number;
        mn: string;
        hd: boolean;
    }[];
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
})[];
export var markers: {
    tm: number;
    cm: string;
    dr: number;
}[];
export var nm: string;
export var op: number;
export var props: {};
/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export var v: string;
export var w: number;
export { header_animated_db2_dark_03 as default };
