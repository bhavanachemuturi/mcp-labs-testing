export var assets: {
    id: string;
    nm: string;
    fr: number;
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        ip: number;
        op: number;
        st: number;
        bm: number;
        parent?: undefined;
        shapes?: undefined;
        ct?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ty: string;
                it: ({
                    d: number;
                    ty: string;
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    a?: undefined;
                    r?: undefined;
                    o?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    d?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                o?: undefined;
                w?: undefined;
                g?: undefined;
                s?: undefined;
                e?: undefined;
                t?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                ml2?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                g: {
                    p: number;
                    k: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                };
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number;
                            y: number;
                        };
                        o: {
                            x: number;
                            y: number;
                        };
                        t: number;
                        s: number[];
                        to: number[];
                        ti: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                        to?: undefined;
                        ti?: undefined;
                    })[];
                    ix: number;
                };
                e: {
                    a: number;
                    k: ({
                        i: {
                            x: number;
                            y: number;
                        };
                        o: {
                            x: number;
                            y: number;
                        };
                        t: number;
                        s: number[];
                        to: number[];
                        ti: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                        to?: undefined;
                        ti?: undefined;
                    })[];
                    ix: number;
                };
                t: number;
                lc: number;
                lj: number;
                ml: number;
                ml2: {
                    a: number;
                    k: number;
                    ix: number;
                };
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                ix?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
                w?: undefined;
                g?: undefined;
                e?: undefined;
                t?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                ml2?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ty: string;
                it: ({
                    d: number;
                    ty: string;
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    a?: undefined;
                    r?: undefined;
                    o?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    d?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                o?: undefined;
                w?: undefined;
                g?: undefined;
                s?: undefined;
                e?: undefined;
                t?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                ml2?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                g: {
                    p: number;
                    k: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                };
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number;
                            y: number;
                        };
                        o: {
                            x: number;
                            y: number;
                        };
                        t: number;
                        s: number[];
                        to: number[];
                        ti: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                        to?: undefined;
                        ti?: undefined;
                    })[];
                    ix: number;
                };
                e: {
                    a: number;
                    k: ({
                        i: {
                            x: number;
                            y: number;
                        };
                        o: {
                            x: number;
                            y: number;
                        };
                        t: number;
                        s: number[];
                        to: number[];
                        ti: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                        to?: undefined;
                        ti?: undefined;
                    })[];
                    ix: number;
                };
                t: number;
                lc: number;
                lj: number;
                ml: number;
                ml2: {
                    a: number;
                    k: number;
                    ix: number;
                };
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                ix?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
                w?: undefined;
                g?: undefined;
                e?: undefined;
                t?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                ml2?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
    })[];
}[];
export var ddd: number;
declare namespace header_animated_watsonx_a_light_06 {
    export { v };
    export { fr };
    export { ip };
    export { op };
    export { w };
    export { h };
    export { nm };
    export { ddd };
    export { assets };
    export { layers };
    export { markers };
    export { props };
}
export var fr: number;
export var h: number;
export var ip: number;
export var layers: {
    ddd: number;
    ind: number;
    ty: number;
    nm: string;
    refId: string;
    sr: number;
    ks: {
        o: {
            a: number;
            k: number;
            ix: number;
        };
        r: {
            a: number;
            k: number;
            ix: number;
        };
        p: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        a: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
        s: {
            a: number;
            k: number[];
            ix: number;
            l: number;
        };
    };
    ao: number;
    w: number;
    h: number;
    ip: number;
    op: number;
    st: number;
    ct: number;
    bm: number;
}[];
export var markers: {
    tm: number;
    cm: string;
    dr: number;
}[];
export var nm: string;
export var op: number;
export var props: {};
/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export var v: string;
export var w: number;
export { header_animated_watsonx_a_light_06 as default };
