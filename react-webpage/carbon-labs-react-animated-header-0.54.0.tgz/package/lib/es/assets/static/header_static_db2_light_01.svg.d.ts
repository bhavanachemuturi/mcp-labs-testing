export { header_static_db2_light_01 as default };
/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
declare var header_static_db2_light_01: string;
