export { StaticBackground as default };
declare function StaticBackground({ headerStatic }: {
    headerStatic: any;
}): React.DetailedReactHTMLElement<{
    className: string;
}, HTMLElement> | null;
import React from 'react';
