export { AnimatedHeader as default };
/** Animated Header */
declare function AnimatedHeader({ allTileGroups, ariaLabels, selectedTileGroup, setSelectedTileGroup, description, headerAnimation, headerStatic, productName, userName, welcomeText, contentSwitcherConfig, headerActionConfig, tasksControllerConfig, workspaceSelectorConfig, isLoading, disabledTaskLabel, expandButtonLabel, collapseButtonLabel, tileClickHandler }: {
    allTileGroups: any;
    ariaLabels?: {} | undefined;
    selectedTileGroup: any;
    setSelectedTileGroup: any;
    description: any;
    headerAnimation: any;
    headerStatic: any;
    productName?: string | undefined;
    userName: any;
    welcomeText: any;
    contentSwitcherConfig: any;
    headerActionConfig: any;
    tasksControllerConfig: any;
    workspaceSelectorConfig: any;
    isLoading: any;
    disabledTaskLabel: any;
    expandButtonLabel?: string | undefined;
    collapseButtonLabel?: string | undefined;
    tileClickHandler: any;
}): React.DetailedReactHTMLElement<{
    className: string;
    "data-expanded": boolean;
}, HTMLElement>;
declare namespace AnimatedHeader {
    let displayName: string;
    namespace propTypes {
        let allTileGroups: PropTypes.Requireable<(object | null | undefined)[]>;
        let ariaLabels: PropTypes.Requireable<object>;
        let className: PropTypes.Requireable<string>;
        let collapseButtonLabel: PropTypes.Requireable<string>;
        let contentSwitcherConfig: PropTypes.Requireable<PropTypes.InferProps<{
            items: PropTypes.Validator<NonNullable<PropTypes.InferProps<{
                id: PropTypes.Requireable<string>;
                text: PropTypes.Validator<string>;
                onSelect: PropTypes.Requireable<(...args: any[]) => any>;
            }>>[]>;
            ariaLabel: PropTypes.Requireable<string>;
            isLoading: PropTypes.Requireable<boolean>;
            lowContrast: PropTypes.Requireable<boolean>;
            headerExpanded: PropTypes.Requireable<boolean>;
            visibleCount: PropTypes.Requireable<number>;
            onChange: PropTypes.Requireable<(...args: any[]) => any>;
        }>>;
        let description: PropTypes.Requireable<string>;
        let expandButtonLabel: PropTypes.Requireable<string>;
        let headerActionConfig: PropTypes.Requireable<PropTypes.InferProps<{
            type: PropTypes.Validator<string>;
            iconButton: PropTypes.Requireable<PropTypes.InferProps<{
                icon: PropTypes.Validator<NonNullable<PropTypes.ReactComponentLike>>;
                iconLabel: PropTypes.Validator<string>;
                onClick: PropTypes.Validator<(...args: any[]) => any>;
                disabled: PropTypes.Requireable<boolean>;
                ariaLabel: PropTypes.Requireable<string>;
                propsOverrides: PropTypes.Requireable<object>;
            }>>;
            ghostButton: PropTypes.Requireable<PropTypes.InferProps<{
                label: PropTypes.Validator<string>;
                icon: PropTypes.Requireable<PropTypes.ReactComponentLike>;
                onClick: PropTypes.Validator<(...args: any[]) => any>;
                disabled: PropTypes.Requireable<boolean>;
                ariaLabel: PropTypes.Requireable<string>;
                propsOverrides: PropTypes.Requireable<object>;
            }>>;
        }>>;
        let headerAnimation: PropTypes.Requireable<object>;
        let headerStatic: PropTypes.Requireable<object>;
        let isLoading: PropTypes.Requireable<boolean>;
        let productName: PropTypes.Requireable<string>;
        let selectedTileGroup: PropTypes.Requireable<object>;
        let setSelectedTileGroup: PropTypes.Requireable<(...args: any[]) => any>;
        let tasksControllerConfig: PropTypes.Requireable<PropTypes.InferProps<{
            type: PropTypes.Validator<string>;
            isLoading: PropTypes.Requireable<boolean>;
            button: PropTypes.Requireable<PropTypes.InferProps<{
                text: PropTypes.Validator<string>;
                propsOverrides: PropTypes.Requireable<object>;
            }>>;
            dropdown: PropTypes.Requireable<PropTypes.InferProps<{
                label: PropTypes.Requireable<string>;
                ariaLabel: PropTypes.Requireable<string>;
                propsOverrides: PropTypes.Requireable<object>;
            }>>;
        }>>;
        let tileClickHandler: PropTypes.Requireable<(...args: any[]) => any>;
        let userName: PropTypes.Requireable<string>;
        let welcomeText: PropTypes.Requireable<string>;
        let workspaceSelectorConfig: PropTypes.Requireable<PropTypes.InferProps<{
            propsOverrides: PropTypes.Requireable<object>;
            allWorkspaces: PropTypes.Requireable<(object | null | undefined)[]>;
            selectedWorkspace: PropTypes.Requireable<object>;
            setSelectedWorkspace: PropTypes.Validator<(...args: any[]) => any>;
        }>>;
    }
}
import React from 'react';
import PropTypes from 'prop-types';
