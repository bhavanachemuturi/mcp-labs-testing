export { TasksController as default };
declare function TasksController({ tasksControllerConfig, isLoading, allTileGroups, selectedTileGroup, setSelectedTileGroup }: {
    tasksControllerConfig: any;
    isLoading: any;
    allTileGroups: any;
    selectedTileGroup: any;
    setSelectedTileGroup: any;
}): React.FunctionComponentElement<import("@carbon/react").ButtonProps<React.ElementType<any, keyof React.JSX.IntrinsicElements>>> | React.FunctionComponentElement<import("@carbon/react").SkeletonPlaceholderProps> | React.DetailedReactHTMLElement<{
    className: string;
}, HTMLElement> | null;
import React from 'react';
