export { ContentSwitcherSelector as default };
declare function ContentSwitcherSelector({ contentSwitcherConfig, isLoading, headerExpanded }: {
    contentSwitcherConfig: any;
    isLoading: any;
    headerExpanded: any;
}): React.FunctionComponentElement<import("@carbon/react").SkeletonPlaceholderProps> | React.DetailedReactHTMLElement<{
    className: string;
    "data-expanded": any;
}, HTMLElement> | null;
import React from 'react';
