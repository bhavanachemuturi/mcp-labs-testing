export { AnimatedBackground as default };
declare function AnimatedBackground({ headerAnimation, isOpen }: {
    headerAnimation: any;
    isOpen: any;
}): React.DetailedReactHTMLElement<{
    className: string;
}, HTMLElement>;
import React from 'react';
