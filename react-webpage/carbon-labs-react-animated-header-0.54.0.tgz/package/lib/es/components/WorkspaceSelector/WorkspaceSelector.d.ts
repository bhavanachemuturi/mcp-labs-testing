export { WorkspaceSelector as default };
declare function WorkspaceSelector({ workspaceSelectorConfig, userName, isLoading }: {
    workspaceSelectorConfig: any;
    userName: any;
    isLoading: any;
}): React.FunctionComponentElement<import("@carbon/react").SkeletonPlaceholderProps> | React.FunctionComponentElement<import("@carbon/react").DropdownProps<unknown> & {
    ref?: React.Ref<HTMLButtonElement>;
}> | null;
import React from 'react';
