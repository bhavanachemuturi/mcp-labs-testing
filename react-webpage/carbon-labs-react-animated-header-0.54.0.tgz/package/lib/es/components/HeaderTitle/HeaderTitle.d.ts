export { HeaderTitle as default };
declare function HeaderTitle({ userName, welcomeText, headerExpanded, ariaLabels }: {
    userName: any;
    welcomeText: any;
    headerExpanded: any;
    ariaLabels: any;
}): React.FunctionComponentElement<import("@carbon/react").TooltipProps<React.ElementType<any, keyof React.JSX.IntrinsicElements>>>;
import React from 'react';
