export function BaseTile(props: any): React.FunctionComponentElement<import("../AITile/AITile.js").AITileProps> | React.FunctionComponentElement<import("../AIPromptTile/AIPromptTile.js").AIPromptTileProps> | React.FunctionComponentElement<import("../GlassTile/GlassTile.js").GlassTileProps>;
import React from 'react';
