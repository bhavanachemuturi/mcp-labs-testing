export function GlassTileBody({ open, title, subtitle, customContent, primaryIcon: PrimaryIcon, secondaryIcon: SecondaryIcon, tagLabel, tagType, isLoading }: {
    open: any;
    title: any;
    subtitle: any;
    customContent: any;
    primaryIcon: any;
    secondaryIcon: any;
    tagLabel: any;
    tagType?: string | undefined;
    isLoading: any;
}): React.FunctionComponentElement<import("@carbon/react").SkeletonPlaceholderProps> | React.DetailedReactHTMLElement<{
    className: string;
    "data-expanded": any;
}, HTMLElement>;
import React from 'react';
