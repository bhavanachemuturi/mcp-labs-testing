export function GlassTile({ tileId, href, title, subtitle, disabledTaskLabel, customContent, primaryIcon: PrimaryIcon, secondaryIcon: SecondaryIcon, tagLabel, tagType, onClick: glassTileClickHandler, ariaLabel, open, isLoading, isDisabled, ...rest }: {
    [x: string]: any;
    tileId: any;
    href: any;
    title: any;
    subtitle: any;
    disabledTaskLabel: any;
    customContent: any;
    primaryIcon: any;
    secondaryIcon: any;
    tagLabel: any;
    tagType: any;
    onClick: any;
    ariaLabel: any;
    open: any;
    isLoading: any;
    isDisabled: any;
}): React.DetailedReactHTMLElement<any, HTMLElement> | React.FunctionComponentElement<import("@carbon/react").LinkProps<React.ElementType<any, keyof React.JSX.IntrinsicElements>>>;
import React from 'react';
