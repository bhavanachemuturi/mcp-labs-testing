export function AIPromptTile({ tileId, href, title, disabledTaskLabel, productName, promptPlaceholder, primaryIcon: PrimaryIcon, aiLabelVariant, aiLabelText, aiLabelTagType, onClick, ariaLabel, open, isLoading, isDisabled, ...rest }: {
    [x: string]: any;
    tileId: any;
    href: any;
    title: any;
    disabledTaskLabel: any;
    productName: any;
    promptPlaceholder?: string | undefined;
    primaryIcon: any;
    aiLabelVariant?: string | undefined;
    aiLabelText?: string | undefined;
    aiLabelTagType?: string | undefined;
    onClick: any;
    ariaLabel: any;
    open: any;
    isLoading: any;
    isDisabled: any;
}): React.DetailedReactHTMLElement<any, HTMLElement>;
import React from 'react';
