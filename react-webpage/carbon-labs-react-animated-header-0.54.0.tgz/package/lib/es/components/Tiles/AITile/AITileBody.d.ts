export function AITileBody({ open, title, subtitle, customContent, primaryIcon: PrimaryIcon, secondaryIcon: SecondaryIcon, aiLabelVariant, aiLabelText, aiLabelTagType, isLoading }: {
    open: any;
    title: any;
    subtitle: any;
    customContent: any;
    primaryIcon: any;
    secondaryIcon: any;
    aiLabelVariant?: string | undefined;
    aiLabelText?: string | undefined;
    aiLabelTagType?: string | undefined;
    isLoading: any;
}): React.FunctionComponentElement<import("@carbon/react").SkeletonPlaceholderProps> | React.DetailedReactHTMLElement<{
    className: string;
    "data-expanded": any;
}, HTMLElement>;
import React from 'react';
