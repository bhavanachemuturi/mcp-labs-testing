export { HeaderAction as default };
declare function HeaderAction({ config, headerExpanded }: {
    config: any;
    headerExpanded: any;
}): React.DetailedReactHTMLElement<{
    className: string;
    "aria-label": any;
    "aria-hidden": boolean;
    "data-expanded": any;
}, HTMLElement> | undefined;
import React from 'react';
